"""def sumar(op1,op2):
    print("El resultado de la suma es: ",op1+op2)

def restar(op1,op2):
    print("El resultado de la resta es: ",op1-op2)

def muliplicar(op1,op2):
    print("El resultado de la multiplicación es: ",op1*op2)

def dividir(op1,op2):
    print("El resultado de la división es: ",op1/op2)

def elevar(base,expo):
    print("El resultado de la potencia es: ",base**expo)

def redondear(op1):
    print("El resultado de la multiplicación es: ",round(op1))"""
def elevar(base,expo):
    print("El resultado de la potencia es: ",base**expo)

def redondear(op1):
    print("El resultado de la multiplicación es: ",round(op1))
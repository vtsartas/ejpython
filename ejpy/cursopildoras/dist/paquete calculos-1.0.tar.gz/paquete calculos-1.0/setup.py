from setuptools import setup

setup(
    name="paquete calculos",
    version="1.0",
    description="Paquete de operaciones básicas y de potencia/redondeo",
    author="Isidoro",
    packages=["calculos","calculos.redondeo_potencia"]


)